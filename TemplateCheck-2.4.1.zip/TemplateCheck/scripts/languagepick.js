let counter = 1;

function toggleItem(item, languageCode) {
  if (item.classList.contains('selected')) {
    // Видаляємо вибір: прибираємо клас і id
    item.classList.remove('selected');
    item.id = '';
    console.log('toggleItem: Знято вибір мови', languageCode);
  } else {
    // Додаємо вибір: встановлюємо клас і генеруємо унікальний id
    item.classList.add('selected');
    item.id = Date.now();
    console.log('toggleItem: Вибрана мова', languageCode, 'з id:', item.id);
  }
  // Після кожної зміни оновлюємо збережений стан
  saveState();

  // Якщо у вас є dropdown, скидаємо його значення, щоб не підвантажувати попередній пресет
  const dropdown = document.getElementById('savedLanguageLists');
  if (dropdown) {
    dropdown.value = '';
    console.log("toggleItem: Скинуто значення dropdown");
  }
}


function saveState() {
  const selectedItems = Array.from(document.querySelectorAll('#itemList li.selected')).map(item => ({
    id: item.id,
    languageCode: item.textContent.trim()
  }));
  localStorage.setItem('selectedLanguages', JSON.stringify(selectedItems));
  console.log("saveState: Збережено обрані мови", selectedItems);
}

function loadState() {
  const itemList = document.getElementById('itemList');
  const savedItems = JSON.parse(localStorage.getItem('selectedLanguages')) || [];
  console.log("loadState: Завантажено збережені мови", savedItems);
  savedItems.forEach(savedItem => {
    const item = Array.from(itemList.getElementsByTagName('li')).find(it => it.textContent.trim() === savedItem.languageCode);
    if (item) {
      item.classList.add('selected');
      item.id = savedItem.id;
    }
  });
}


document.getElementById('itemList').addEventListener('click', function (event) {
  if (event.target.tagName === 'LI') {
    toggleItem(event.target, event.target.innerText);
  }
});
